package javawebfactoryapp.main;

public interface IShape {
	
	void draw();
}
