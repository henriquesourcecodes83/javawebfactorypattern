package javawebfactoryapp.main;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = "/shapeservlet")
public class ShapeServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out = resp.getWriter();
		
		out.println("<html>");
		out.println("<body>");	
						
		IShape shape = new ShapeFactory().getShape(ShapeType.valueOf(req.getParameter("shape")));
		
		out.println(shape.getClass().getSimpleName());
		
		out.println("</body>");
		out.println("</html>");
		
	}
	
}
