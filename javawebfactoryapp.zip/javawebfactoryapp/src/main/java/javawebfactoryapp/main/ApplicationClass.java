package javawebfactoryapp.main;

public class ApplicationClass {

}
