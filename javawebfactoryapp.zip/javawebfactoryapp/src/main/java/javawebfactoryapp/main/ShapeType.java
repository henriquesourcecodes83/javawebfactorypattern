package javawebfactoryapp.main;

public enum ShapeType {
	
	CIRCLE, RECTANGLE, SQUARE
	
}
