package javawebfactoryapp.main;

public class ShapeFactory {
	
	public IShape getShape(ShapeType type) {
		
		IShape shape = null;
		
		if(type == ShapeType.CIRCLE) {			
			shape = new Circle();
			
		} else if(type == ShapeType.RECTANGLE) {
			shape = new Rectangle();
			
		} else if (type == ShapeType.SQUARE) {
			shape = new Square();
			
		}
		
		return shape;
		
	}

}
