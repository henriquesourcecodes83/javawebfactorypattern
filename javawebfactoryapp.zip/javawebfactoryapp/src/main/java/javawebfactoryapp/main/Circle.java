package javawebfactoryapp.main;

public class Circle implements IShape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.print(this.getClass());
		
	}

}
